# Promly CMS
### Tecnologies:
- React & TypeScript: https://react.dev/
- Vite - Bundler: https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md
- TailwindCss - CSS framework: https://tailwindcss.com/
- Material UI - React UI components: https://mui.com/material-ui/getting-started/

### Running the app
This app is developed & built on Nodejs 18.15.0. So make sure you have that node version on you local.
It would be the best if you can use nvm to manage Nodejs versions on local: https://github.com/nvm-sh/nvm

To run this app on local, please follow the steps below:
```bash
# Git clone this repo and cd to the source folder

# Run this command to use nodejs 18.15.0 if you're using nvm
$ nvm use 18.15.0

# Install dependencies
$ yarn install

# development in watch mode.
$ yarn run start # this will run the webapp with the .env.staging environment, means it will connect to Staging api: https://promly-api-qa.com

# production mode
$ yarn run start:prod

```

### Folder structure
    .
    ├── dist                            # Compiled files
    ├── [public](public)                # Contains images
    ├── [src](src)
    │   ├── [common](src%2Fcommon)      # Contains shared components. Ex: interest_list, loading, uploader,...
    │   ├── [features](src%2Ffeatures)  # Contains all the main features
    │   │   ├── Each feature normally has:
    │   │   ├── page                    # Contains the main components of each route. Ex route `/accounts` has component AccountList as entry
    │   │   ├── components              # Contains child components that being used in main components (The page components)
    │   │   ├── services                # Contains services for handling API requests (simple classes with static functions)
    │   ├── [layouts](src%2Flayouts)    # Contains components of the main layout. Ex: Header, Nav, Main Layout, Secondary Layout...
    │   ├── [scss](src%2Fscss)          # Contains the common styles writting in sass format
    │   ├── [store](src%2Fstore)        # Contains all things related to Store management - Redux
    │   └── [utils](src%2Futils)        # Contains utility functions
    ├── [.env.production](.env.production)      # Environment variables for Production
    ├── [.env.staging](.env.staging)      # Environment variables for Staging
    ├── ... # Other files for configurations of eslint, postcss, tsconfig, tailwind, vite...
    └── README.md


### Bundle the code
```bash
# For staging
$ yarn build --mode staging

# For production
yarn build --mode production

```
