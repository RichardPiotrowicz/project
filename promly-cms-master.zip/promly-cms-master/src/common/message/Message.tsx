import Snackbar from '@mui/material/Snackbar';
import MuiAlert, { AlertProps } from '@mui/material/Alert';
import { forwardRef, SyntheticEvent } from 'react';

const Alert = forwardRef<HTMLDivElement, AlertProps>(function Alert(
  props,
  ref,
) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

interface MessageProps {
  error?: string[];
  success?: string[];
  callback?: () => void;
}


export default function Message({error, success, callback}: MessageProps) {
  success = Array.isArray(success) ? success : [];
  error = Array.isArray(error) ? error : [];
  const handleCloseSuccess = (event?: SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway' || !event) {
      return;
    }
    callback && callback();
    // setOpenSuccess(false);
  };
  const handleCloseError = (event?: SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway' || !event) {
      return;
    }
    callback && callback();
    // setOpenError(false);
  };
  return (
    <>
      {success.map((item, index) => (
        <Snackbar key={`g-success-${index}`} open={true} autoHideDuration={4000} onClose={handleCloseSuccess}>
          <Alert onClose={handleCloseSuccess} severity="success" sx={{ width: '100%' }}>
            {item}
          </Alert>
        </Snackbar>
      ))}

      {error.map((item, index) => (
        <Snackbar key={`g-error-${index}`} open={true} autoHideDuration={4000} onClose={handleCloseError}>
          <Alert onClose={handleCloseError} severity="error" sx={{ width: '100%' }}>
            {item}
          </Alert>
        </Snackbar>
      ))}
    </>
  );
}
