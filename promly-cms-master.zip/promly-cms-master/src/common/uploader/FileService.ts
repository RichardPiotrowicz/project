import axios from 'axios';
const axiosExternal = axios.create();

const API_URL = import.meta.env.VITE_API_URL;
export class FileService {
  static async getPresignedUrl(fileName: string, type: 'photo' | 'video') {
    const res = await axios.post(`${API_URL}/files/presigned-url`, {fileName, type});
    return res.data;
  }

  static async uploadFile(file: File, url: string) {
    await axiosExternal.put(url, file, {
      headers: { 'Content-Type': file.type},
      maxContentLength: (100 * 1024 * 1024 * 1024),
      timeout: (30 * 60 * 1000),
    })
    return true;
  }
}
