import './Uploader.scss';
import { MuiFileInput } from 'mui-file-input';
import { useState } from 'react';
import { FileService } from './FileService.ts';
import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';

interface UploaderProps {
  imageUrl?: string;
  callbackUploaded?: (imageId: string, imageUrl: string) => void;
  callbackRemove?: () => void;
}

export default function Uploader({ imageUrl, callbackUploaded, callbackRemove }: UploaderProps) {
  const [ file, setFile ] = useState(null);
  const [ uploading, setUploading ] = useState(false);
  const uploadFile = async (file: File) => {
    setUploading(true);
    const res = await FileService.getPresignedUrl(file.name, 'photo');
    const {url, fileId} = res.data;
    await FileService.uploadFile(file, url);
    setUploading(false);
    const tmp = url.split('?');
    callbackUploaded(fileId, tmp[0]);
  };

  const handleChange = (newFile) => {
    setFile(newFile);
    if (newFile) {
      uploadFile(newFile);
    }
  };

  const handleRemove = () => {
    setFile(null);
    callbackRemove();
  };
  return (
    <div className='relative'>
      {imageUrl ? (
        <div className='flex items-center border p-2'>
          <div className='w-[200px]'>
            <img
              srcSet={imageUrl}
              src={imageUrl}
              loading='lazy'
            />
          </div>
          <Button className='ml-4' startIcon={<DeleteIcon />} color='secondary' onClick={handleRemove}>
            Remove image
          </Button>
        </div>
      ) : (
        <MuiFileInput
          className='w-full'
          placeholder='Select an image'
          inputProps={{ accept: '.png, .jpeg' }}
          value={file}
          onChange={handleChange}
        />
      )}
      {uploading ? (<Box className='flex absolute left-0 top-0 w-full h-full items-center justify-center bg-slate-100/50 z-10'>
        <CircularProgress />
      </Box>) : null}
    </div>


  );
}
