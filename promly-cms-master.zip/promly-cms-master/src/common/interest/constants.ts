const color = {
  coralRed: '#FF0A45',
  tangerine: '#FA880C',
  lemon: '#E5E301',
  lime: '#0BE014',
  skye: '#04D4F9',
  purple: '#AA57FF',
  deepPink: '#FF1696',
  x1: '#D1F7C4',
  x2: '#8B46FF',
  x3: '#CCCCCC',
};
export const INTERESTS = [
  {
    name: 'finance',
    metadata: { bgColor: color.skye, textColor: '#ffffff' },
  },
  {
    name: 'mentalhealth',
    metadata: { bgColor: color.x1, textColor: '#333333' },
  },
  {
    name: 'adventure',
    metadata: { bgColor: color.tangerine, textColor: '#ffffff' },
  },
  {
    name: 'tv/movies',
    metadata: { bgColor: color.lime, textColor: '#ffffff' },
  },
  {
    name: 'music',
    metadata: { bgColor: color.coralRed, textColor: '#ffffff' },
  },
  {
    name: 'books',
    metadata: { bgColor: color.purple, textColor: '#ffffff' },
  },
  {
    name: 'sports',
    metadata: { bgColor: color.purple, textColor: '#ffffff' },
  },
  {
    name: 'activism',
    metadata: { bgColor: color.x1, textColor: '#333333' },
  },
  {
    name: 'lifestyle',
    metadata: { bgColor: color.x3, textColor: '#333333' },
  },
  {
    name: 'arts',
    metadata: { bgColor: color.deepPink, textColor: '#ffffff' },
  },
  {
    name: 'food',
    metadata: { bgColor: color.lime, textColor: '#ffffff' },
  },
  {
    name: 'travel',
    metadata: { bgColor: color.coralRed, textColor: '#ffffff' },
  },
  {
    name: 'play/games',
    metadata: { bgColor: color.deepPink, textColor: '#ffffff' },
  },
  {
    name: 'create',
    metadata: { bgColor: color.x2, textColor: '#ffffff' },
  },
  {
    name: 'stem',
    metadata: { bgColor: color.tangerine, textColor: '#ffffff' },
  },
  {
    name: 'anxiety',
    metadata: { bgColor: color.coralRed, textColor: '#ffffff' },
  },
  {
    name: 'socialevents',
    metadata: { bgColor: color.purple, textColor: '#ffffff' },
  },
  {
    name: 'pets/animals',
    metadata: { bgColor: color.x2, textColor: '#ffffff' },
  },
];
