import './InterestTags.scss';
import { INTERESTS } from './constants.ts';

interface InterestTagsProps {
  items: {
    name: string;
    metadata: {
      bgColor: string;
      textColor: string;
    }
  }[];
}

export default function InterestTags({ items }: InterestTagsProps) {
  const mapper = new Map();
  INTERESTS.forEach((item) => {
    mapper.set(item.name, item.metadata);
  })
  items = Array.isArray(items) ? items: [];
  items = items.map((item) => ({...item, metadata: mapper.get(item.name)}))
  return (
    <div className="interest-tags">
      {items.map((item) => (
        <div className='tag-item ml-2' style={{ color: item.metadata.textColor, backgroundColor : item.metadata.bgColor }} key={item.name}>{item.name}</div>
      ))}
    </div>
  );
}
