import './Loading.scss';
export default function Loading() {
  return (
    <div className="s-loading">
      <svg className="svg-e" viewBox="25 25 50 50">
        <circle className="svg-path" cx="50" cy="50" r="20" fill="none" strokeWidth="4" strokeMiterlimit="10" />
      </svg>
    </div>

  );
}
