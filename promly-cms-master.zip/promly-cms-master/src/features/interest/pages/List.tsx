export default function InterestList() {
  return (
    <div className="interest-page">
      Interest list
    </div>
  );
}
