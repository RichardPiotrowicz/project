import { useEffect, useState } from 'react';
import Loading from '../../../common/loading/Loading.tsx';
import { PostReportService } from '../services/PostReportService.ts';
import { Menu } from '@headlessui/react';
import format from 'date-fns/format';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogActions from '@mui/material/DialogActions';
import Dialog from '@mui/material/Dialog';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import ImageOutlinedIcon from '@mui/icons-material/ImageOutlined';
import PlayCircleOutlinedIcon from '@mui/icons-material/PlayCircleOutlined';

export default function ReportList() {
  const [ loading, setLoading ] = useState(true);
  const [ items, setItems ] = useState([]);
  const [ page, setPage ] = useState(1);
  const take = 10;
  const [ openDeleteBox, setOpenDeleteBox ] = useState(false);
  const [ openBackdrop, setOpenBackdrop ] = useState(false);
  const [ currentItem, setCurrentItem ] = useState(null);


  const loadData = () => {
    setLoading(true);
    const params: any = {
      take, skip: take * (page - 1),
    };
    PostReportService.get(params)
      .then((res) => {
        setItems(res.data.items);
      })
      .finally(() => {
        setLoading(false);
      });
  };
  useEffect(() => {
    loadData();
  }, [ page ]);
  const nextPage = async () => {
    setPage(page + 1);
  };
  const prevPage = async () => {
    setPage(page > 1 ? (page - 1) : 1);
  };
  const handleDeleteBoxClose = () => {
    setOpenBackdrop(false);
    setOpenDeleteBox(false);
  };
  const handleDeleteBoxSubmit = async () => {
    setOpenBackdrop(true);
    try {
      await PostReportService.deletePost(currentItem.id);
      setItems(items.filter(item => item.id !== currentItem.id));
      setOpenDeleteBox(false);
    } catch (e) {
      //
    } finally {
      setOpenBackdrop(false);
    }
  };

  const showDeleteBox = (item: any) => {
    setCurrentItem(item);
    setOpenBackdrop(true);
    setOpenDeleteBox(true);
  };
  const ignoreReport = async (id: string) => {
    try {
      await PostReportService.ignore(id);
      const newItems = items.map(item => {
        if (item.id === id) {
          return {...item, status: 'ignored'};
        }
        return {...item};
      })
      setItems(newItems);
    } catch (e) {
      //
    }
  };

  return (
    <div className='post-report-page'>
      <div className='text-sm font-bold uppercase mb-3'>Post reports</div>

      {loading && (
        <div className='w-full relative h-40'><Loading /></div>
      )}

      {!loading && (
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
          <TableContainer sx={{ maxHeight: 'calc(100vh - 300px)' }} className='border-b-1 border-gray-300'>
            <Table stickyHeader aria-label='sticky table' size="small" className='pb-20'>
              <TableHead>
                <TableRow>
                  <TableCell>Post ID</TableCell>
                  <TableCell>Username</TableCell>
                  <TableCell align='center'>Type</TableCell>
                  <TableCell>Post Description</TableCell>
                  <TableCell>Image</TableCell>
                  <TableCell>Video</TableCell>
                  <TableCell>Report Description</TableCell>
                  <TableCell align='center'>Status</TableCell>
                  <TableCell>Created At</TableCell>
                  <TableCell>Updated At</TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {items
                  .map((item) => {
                    return (
                      <TableRow tabIndex={-1} key={item.id}>
                        <TableCell>
                          {item.postId}
                        </TableCell>
                        <TableCell>
                          {item?.post?.account?.username}
                        </TableCell>
                        <TableCell align='center'>
                          {item?.post?.type}
                        </TableCell>
                        <TableCell>
                          <div className='max-w-[250px] whitespace-break-spaces'>{item?.post?.description}</div>
                        </TableCell>
                        <TableCell>
                          {item?.post?.imageUrl ? (
                            <IconButton color="primary" aria-label="View image" href={item.post.imageUrl} target='_blank'>
                              <ImageOutlinedIcon />
                            </IconButton>
                          ) : null}
                        </TableCell>
                        <TableCell>
                          {item?.post?.videoUrl ? (
                            <IconButton color="primary" aria-label="View image" href={'https://m3u8play.dev/?url=' + item.post.videoUrl} target='_blank'>
                              <PlayCircleOutlinedIcon />
                            </IconButton>
                          ) : null}
                        </TableCell>
                        <TableCell>
                          <div className='max-w-[250px] whitespace-break-spaces'>{item.description}</div>
                        </TableCell>
                        <TableCell align='center'>
                          {item.status}
                        </TableCell>
                        <TableCell
                          className='whitespace-nowrap'>{format(new Date(item.createdAt), 'yyyy-MM-dd')}</TableCell>
                        <TableCell
                          className='whitespace-nowrap'>{format(new Date(item.updatedAt), 'yyyy-MM-dd')}</TableCell>
                        <TableCell>
                          <Menu as='div' className='relative inline-block text-left'>
                            <div>
                              <Menu.Button className='btn-action'>
                                <MoreVertIcon className='text-gray-500' />
                              </Menu.Button>
                            </div>
                            <Menu.Items className='s-menu'>
                              <Menu.Item>
                                <button className='s-menu__btn' onClick={() => ignoreReport(item.id)}>Ignore this</button>
                              </Menu.Item>
                              <Menu.Item>
                                <button className='s-menu__btn' onClick={() => showDeleteBox(item)}>Delete the post</button>
                              </Menu.Item>
                            </Menu.Items>
                          </Menu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          </TableContainer>

          <div className='mt-2 py-2 flex items-center justify-end  pr-4'>
            <span className='mr-8'>Rows per page: {take}</span>
            <span className='mr-8'>Page: {page}</span>
            <IconButton color="primary" aria-label="Previous" onClick={prevPage} disabled={page === 1}>
              <ChevronLeftIcon />
            </IconButton>
            <IconButton color="primary" aria-label="Next" onClick={nextPage}>
              <ChevronRightIcon />
            </IconButton>
          </div>
        </Paper>
      )}

      <Dialog
        open={openDeleteBox}
        onClose={handleDeleteBoxClose}
        aria-labelledby='alert-dialog-title'
        aria-describedby='alert-dialog-description'
      >
        <DialogContent>
          <DialogContentText id='alert-dialog-description'>
            Are you sure you want to delete the post?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteBoxClose}>Cancel</Button>
          <Button onClick={handleDeleteBoxSubmit} autoFocus>
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      <Backdrop
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={openBackdrop}
      >
        <CircularProgress color='inherit' />
      </Backdrop>
    </div>
  );
}
