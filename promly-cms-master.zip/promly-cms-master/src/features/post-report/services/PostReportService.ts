import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL;

export class PostReportService {
  static async get(params: any) {
    const res = await axios.get(`${API_URL}/post-reports`, { params });
    return res.data;
  }

  static async update(id: string, data: any) {
    const res = await axios.patch(`${API_URL}/post-reports/${id}`, data);
    return res.data;
  }

  static async deletePost(id: string) {
    const res = await axios.delete(`${API_URL}/post-reports/${id}/post`);
    return res.data;
  }

  static async ignore(id: string) {
    const res = await axios.patch(`${API_URL}/post-reports/${id}/ignore`);
    return res.data;
  }
}
