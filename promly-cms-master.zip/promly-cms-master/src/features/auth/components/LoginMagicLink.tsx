import { Button, TextInput } from '@tremor/react';
import { EnvelopeIcon } from '@heroicons/react/24/solid';
import { AuthService } from '../services/AuthService.ts';
import { FormEvent, useState } from 'react';
import { APIResponseUtility } from '../../../utils/APIResponse.tsx';
import { ChevronDoubleLeftIcon } from '@heroicons/react/24/outline';

export default function LoginMagicLink(props: {onGoBack: any}) {
  const { onGoBack } = props;
  const [ formState, setFormState ] = useState({
    email: null,
    emailError: null,
    errorMessage: null,
    loading: null,
    magicLink: null,
    successMessage: null,
  });
  const sendMagicLink = async (e: FormEvent) => {
    e.preventDefault();
    const errors: any = {};
    if (!formState.email) {
      errors.emailError = 'Required';
      setFormState({...formState, ...errors});
      return;
    }
    try {
      setFormState({...formState, loading: true});
      await AuthService.sendMagicLink(formState.email);
      setFormState({...formState, successMessage: 'A magic link has been sent to the email.', loading: false});
    } catch (e) {
      setFormState({...formState, errorMessage: APIResponseUtility.parseErrors(e), loading: false});
    }
  };
  return (
    <form className='auth-form max-w-xs' onSubmit={sendMagicLink}>
      <div className='auth-form__title !mb-10'>Welcome to Promly Admin</div>
      {!formState.successMessage && (
        <>
          <div className='flex flex-col'>
            <TextInput icon={EnvelopeIcon} placeholder='Email'
                       error={!!formState.emailError} errorMessage={formState.emailError}
                       onChange={(e) => setFormState({...formState, email: e.target.value, emailError: null})} />
          </div>

          {formState.errorMessage && <div className='my-3 text-red-400 text-sm'>{formState.errorMessage}</div>}

          <div className='flex mt-4'>
            <Button type='submit' className='w-full' loading={formState.loading} id='login-submit'>Send a magic link</Button>
          </div>
        </>
      )}

      {formState.successMessage && (<div className='my-3 text-green-400 text-sm'>{formState.successMessage}</div>)}

      <div className='flex'>
        <button type='button' className='flex items-center text-black hover:text-gray-400 text-sm mt-2 underline'
                onClick={onGoBack}
        >
          <ChevronDoubleLeftIcon className='w-4 h-4 mr-2'/>Back
        </button>
      </div>
    </form>
  );
}
