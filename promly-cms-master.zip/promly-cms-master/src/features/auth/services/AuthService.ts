import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL;
export class AuthService {
  static async loginWithPassword(email: string, password: string) {
    return axios.post(`${API_URL}/admin-auth/login/password`, {
      email, password
    })
  }

  static async loginWithCode(email: string, code: string) {
    return axios.post(`${API_URL}/admin-auth/login/code`, {
      email, code
    })
  }

  static async sendMagicLink(email: string) {
    return axios.post(`${API_URL}/admin-auth/request-login`, {
      email
    })
  }
}
