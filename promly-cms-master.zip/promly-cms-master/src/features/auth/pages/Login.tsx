import '../Auth.scss';
import { useDispatch } from 'react-redux';
import { Button, Flex, TextInput } from '@tremor/react';
import { EnvelopeIcon, LockClosedIcon } from '@heroicons/react/24/solid';
import { setAuthToken } from '../../../store/auth-slice.tsx';
import { AuthService } from '../services/AuthService.ts';
import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { APIResponseUtility } from '../../../utils/APIResponse.tsx';
import LoginMagicLink from '../components/LoginMagicLink.tsx';

export default function Login() {
  const dispatch = useDispatch();
  const [ formState, setFormState ] = useState({
    email: null,
    emailError: null,
    password: null,
    passwordError: null,
    errorMessage: null,
    loading: null,
    magicLink: null,
  });
  const navigate = useNavigate();
  const login = async (e: FormEvent) => {
    e.preventDefault();
    const errors: any = {};
    if (!formState.email) {
      errors.emailError = 'Required';
    }
    if (!formState.password) {
      errors.passwordError = 'Required';
    }
    if (!formState.email || !formState.password) {
      setFormState({...formState, ...errors});
      return;
    }
    try {
      setFormState({...formState, loading: true});
      const res = await AuthService.loginWithPassword(formState.email, formState.password);
      dispatch(setAuthToken(res.data.data.accessToken));
      navigate('/accounts');
    } catch (e) {
      setFormState({...formState, errorMessage: APIResponseUtility.parseErrors(e), loading: false});
    }
  };

  return (
    <Flex justifyContent='center' alignItems='center'>
      {!formState.magicLink && (
        <form className='auth-form max-w-xs' onSubmit={login}>
          <div className='auth-form__title'>Welcome to Promly Admin</div>
          <div className='text-center mb-4 text-sm font-normal'>Select from the options below.</div>
          <button type='button' className='auth-form__btn' onClick={() => setFormState({...formState, magicLink: true})}>Login by Magic Link</button>

          <div className="flex items-center justify-center or-lbl">
            <span className="!font-bold">Or use email/password</span>
          </div>

          <div className='flex flex-col'>
            <TextInput icon={EnvelopeIcon} placeholder='Email'
                       error={!!formState.emailError} errorMessage={formState.emailError}
                       onChange={(e) => setFormState({...formState, email: e.target.value, emailError: null})} />
          </div>

          <div className='flex flex-col mt-2'>
            <TextInput icon={LockClosedIcon} type='password' placeholder='Password'
                       error={!!formState.passwordError} errorMessage={formState.passwordError}
                       onChange={(e) => setFormState({...formState, password: e.target.value, passwordError: null})} />
          </div>

          {formState.errorMessage && <div className='my-3 text-red-400 text-sm'>{formState.errorMessage}</div>}

          <div className='flex mt-4'>
            <Button type='submit' className='w-full' loading={formState.loading} id='login-submit'>Log in</Button>
          </div>

          {/*<div className='flex justify-center'>*/}
          {/*  <NavLink to="/auth/forgot-password" className='text-black hover:text-gray-400 text-sm mt-2 underline'>Forgot password?</NavLink>*/}
          {/*</div>*/}
        </form>
      )}

      {formState.magicLink && (<LoginMagicLink onGoBack={() => setFormState({...formState, magicLink: false})}/>)}
    </Flex>
  );
}
