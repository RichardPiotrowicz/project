import '../Auth.scss';
import { useDispatch } from 'react-redux';
import { setAuthToken } from '../../../store/auth-slice.tsx';
import { Navigate } from 'react-router-dom';

export default function Logout() {
  const dispatch = useDispatch();
  dispatch(setAuthToken(null));
  return <Navigate to='/auth/login' />;
}
