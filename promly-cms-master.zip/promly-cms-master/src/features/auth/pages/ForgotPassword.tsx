import '../Auth.scss';
import { Button, Flex, TextInput } from '@tremor/react';
import { EnvelopeIcon } from '@heroicons/react/24/solid';
// import { AuthService } from './AuthService.tsx';
import { FormEvent, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { APIResponseUtility } from '../../../utils/APIResponse.tsx';
import { ChevronDoubleLeftIcon } from '@heroicons/react/24/outline';

export default function ForgotPassword() {
  const [ email, setEmail ] = useState(null);
  const [ emailError, setEmailError ] = useState(null);
  const [ errorMessage, setErrorMessage ] = useState(null);
  const navigate = useNavigate();
  const [ loading, setLoading ] = useState(null);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!email) {
      setEmailError('Required');
      return;
    }
    try {
      setLoading(true);
      // await AuthService.forgot(email);
      navigate('/auth/login');
    } catch (e) {
      setErrorMessage(APIResponseUtility.parseErrors(e));
      setLoading(false);
    }
  };
  return (
    <Flex justifyContent='center' alignItems='center'>
      <form className='auth-form max-w-xs' onSubmit={submit}>
        <div className='auth-form__title'>Forgot password</div>
        <div className='flex flex-col'>
          <TextInput icon={EnvelopeIcon} placeholder='Email'
                     error={!!emailError} errorMessage={emailError}
                     onChange={(e) => setEmail(e.target.value)} />
        </div>

        {errorMessage && <div className='my-3 text-red-400 text-sm'>{errorMessage}</div>}

        <div className='flex mt-4'>
          <Button type='submit' className='w-full' loading={loading} id='login-submit'>Log in</Button>
        </div>

        <div className='flex justify-center'>
          <NavLink to="/auth/login" className='flex items-center text-black hover:text-gray-400 text-sm mt-2 underline'><ChevronDoubleLeftIcon className='w-4 h-4 mr-2'/>Back to Login</NavLink>
        </div>
      </form>
    </Flex>
  );
}
