import '../Auth.scss';
import { useDispatch } from 'react-redux';
import { setAuthToken } from '../../../store/auth-slice.tsx';
import { useEffect, useState } from 'react';
import { AuthService } from '../services/AuthService.ts';
import Loading from '../../../common/loading/Loading.tsx';
import { APIResponseUtility } from '../../../utils/APIResponse.tsx';
import { NavLink, useNavigate } from 'react-router-dom';
import { Flex } from '@tremor/react';
import { ChevronDoubleLeftIcon } from '@heroicons/react/24/outline';
import { useSearchParams } from "react-router-dom";

export default function LoginWithCode() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [ formState, setFormState ] = useState({
    loading: false,
    success: false,
    error: null,
  });
  const login = async () => {
    const email = searchParams.get('email');
    const code = searchParams.get('code');
    const redirect = searchParams.get('redirect');
    try {
      setFormState({ ...formState, loading: true });
      const res = await AuthService.loginWithCode(email, code);
      dispatch(setAuthToken(res.data.data.accessToken));
      if (redirect) {
        navigate(decodeURIComponent(redirect));
      } else {
        navigate('/');
      }
    } catch (e) {
      setFormState({ ...formState, loading: false, error: APIResponseUtility.parseErrors(e) });
      console.log(APIResponseUtility.parseErrors(e))
    }
  };
  useEffect(() => {
    login().then(() => {
    });
  }, []);
  return <>
    {formState.loading && (<div className='w-full relative h-40'><Loading /></div>)}
    {!formState.loading && formState.error && (
      <Flex justifyContent='center' alignItems='center'>
        <div className='auth-form max-w-xs'>
          {formState.error.map(m => (<div className='my-1 text-red-400'>{m}</div>))}
          <div className='flex'>
            <NavLink to='/auth/login'
                     className='flex text-black hover:text-gray-400 text-sm mt-2 underline'><ChevronDoubleLeftIcon
              className='w-4 h-4 mr-2' />Back to Login</NavLink>
          </div>
        </div>
      </Flex>
    )}
  </>;
}
