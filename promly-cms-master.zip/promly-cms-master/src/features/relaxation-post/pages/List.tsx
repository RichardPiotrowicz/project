export default function RelaxationPostList() {
  return (
    <div className="relaxation-post-page">
      Relaxation post list
    </div>
  );
}
