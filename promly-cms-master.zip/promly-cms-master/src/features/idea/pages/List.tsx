export default function IdeaList() {
  return (
    <div className="idea-page">
      Idea list
    </div>
  );
}
