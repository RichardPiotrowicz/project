import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Divider from '@mui/material/Divider';
import Container from '@mui/material/Container';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { ChangeEvent, useState } from 'react';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { AdminAccountService } from '../services/AdminAccountService.ts';
import { APIResponseUtility } from '../../../utils/APIResponse.tsx';
import Message from '../../../common/message/Message.tsx';
import { RoleEnum } from '../../account/AccountConstants.ts';

interface RoleDetailProps {
  data: any;
  callback: () => void;
}

const roles = [
  { name: 'Super admin', value: RoleEnum.SuperAdmin },
  { name: 'Administrator', value: RoleEnum.Administrator },
];

export default function RoleDetail({ data, callback }: RoleDetailProps) {
  const [ roleData, setRoleData ] = useState(data ? {
    email: data.email,
    role: data.roles.length ? data.roles[0].name : null,
  } : {
    email: '',
    role: RoleEnum.Administrator,
  });
  const [ error, setError ] = useState([]);
  const isCreate = !data;

  const errorCallback = () => {
    setError([]);
  }

  const submit = async () => {
    try {
      await AdminAccountService.updateOrCreate(roleData, isCreate);
      callback();
    } catch (e) {
      setError(APIResponseUtility.parseErrors(e));
    }
  };

  return (
    <Box
      sx={{ width: 550 }}
      role='presentation'
    >
      <Container>
        <Box
          component='form'
          noValidate
          autoComplete='off'
          className='py-6'
        >
          <Typography variant='h5' component='h5' className='mb-2'>
            Assign roles
          </Typography>
          <Divider />

          <TextField
            label='Email'
            fullWidth
            margin='normal'
            value={roleData.email}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setRoleData({ ...roleData, email: event.target.value })}
          />

          <FormControl margin='normal' fullWidth>
            <InputLabel id="role-select-label">Role</InputLabel>
            <Select
              labelId="role-select-label"
              id="role-select"
              value={roleData.role}
              label="Role"
              onChange={(event: SelectChangeEvent) => setRoleData({ ...roleData, role: event.target.value as any })}
            >
              {roles.map((role) => (
                <MenuItem
                  key={role.value}
                  value={role.value}
                >
                  {role.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <div className='flex justify-end mt-4'>
            <Button variant='contained' className='bg-blue-600' disableElevation onClick={submit}>
              Submit
            </Button>
          </div>
        </Box>

        <Message error={error} callback={errorCallback}/>

      </Container>
    </Box>
  );
}
