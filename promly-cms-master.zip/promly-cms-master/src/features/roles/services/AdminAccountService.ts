import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL;

export class AdminAccountService {
  static async get() {
    const res = await axios.get(`${API_URL}/admin-accounts`);
    return res.data;
  }

  static async create(data: any) {
    const res = await axios.post(`${API_URL}/admin-accounts`, data);
    return res.data;
  }

  static async updateRoles(data: any) {
    const res = await axios.patch(`${API_URL}/admin-accounts/roles`, data);
    return res.data;
  }

  static async delete(data: any) {
    const res = await axios.delete(`${API_URL}/admin-accounts`, { data });
    return res.data;
  }

  static async updateOrCreate(data: any, create?: boolean) {
    if (!create) {
      return this.updateRoles(data);
    }
    return this.create(data);
  }

  static async update(data: any) {
    const res = await axios.patch(`${API_URL}/admin-accounts`, data);
    return res.data;
  }
}
