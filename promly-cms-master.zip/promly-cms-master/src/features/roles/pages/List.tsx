import { useEffect, useState } from 'react';
import Loading from '../../../common/loading/Loading.tsx';
import { AdminAccountService } from '../services/AdminAccountService.ts';
import { Menu } from '@headlessui/react';
import format from 'date-fns/format';
import Button from '@mui/material/Button';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogActions from '@mui/material/DialogActions';
import Dialog from '@mui/material/Dialog';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import Stack from '@mui/material/Stack';
import AddIcon from '@mui/icons-material/Add';
import Drawer from '@mui/material/Drawer';
import RoleDetail from '../components/RoleDetail.tsx';
import Avatar from '@mui/material/Avatar';
import Chip from '@mui/material/Chip';

export default function RoleList() {
  const [ comState, setComState ] = useState({
    loading: false,
    items: [],
    openDeleteBox: false,
    openBackdrop: false,
    currentItem: null,
    savingOrder: false,
    changedOrder: false,
  });
  const [ openDetailBox, setOpenDetailBox ] = useState(false);

  const loadData = async () => {
    setComState({...comState, loading: true});
    try {
      const res = await AdminAccountService.get();
      setComState({...comState, loading: false, items: res.data});
    } catch (e) {
      console.log('error while loading data');
    }
  };
  useEffect(() => {
    loadData();
  }, []);
  const handleDeleteBoxClose = () => {
    setComState({...comState, openBackdrop: false, openDeleteBox: false});
  };
  const handleDeleteBoxSubmit = async () => {
    if (!comState.currentItem) {
      return;
    }
    setComState({...comState, openBackdrop: true});
    try {
      await AdminAccountService.delete({ email: comState.currentItem.email });
    } catch (e) {
      //
    } finally {
      setComState({...comState, openBackdrop: false, openDeleteBox: false, items: comState.items.filter(item => item.id !== comState.currentItem.id)});
    }
  };

  const showDeleteBox = (item: any) => {
    setComState({...comState, openBackdrop: true, openDeleteBox: true, currentItem: item});
  };


  const callbackSaveDetail = () => {
    setOpenDetailBox(false);
    loadData();
  }
  const showEditBox = (item: any) => {
    setComState({...comState, currentItem: item});
    setOpenDetailBox(true);
  };

  return (
    <div className='post-report-page'>
      <div className='text-sm font-bold uppercase mb-3'>Admin Accounts</div>

      <div className='flex flex-row justify-end pb-3 border-b-1 border-gray-200'>
        <Stack spacing={2} direction='row'>
          <Button variant='contained' className='bg-blue-600' disableElevation startIcon={<AddIcon />} onClick={() => showEditBox(null)}>
            Add new admin account
          </Button>
        </Stack>
      </div>

      {comState.loading && (
        <div className='w-full relative h-40'><Loading /></div>
      )}

      {!comState.loading && (
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
          <TableContainer sx={{ maxHeight: 'calc(100vh - 300px)' }} className='border-b-1 border-gray-300'>
            <Table stickyHeader aria-label='sticky table' size="small" className='pb-20'>
              <TableHead>
                <TableRow>
                  <TableCell></TableCell>
                  <TableCell>Name</TableCell>
                  <TableCell>Email</TableCell>
                  <TableCell>Role</TableCell>
                  <TableCell>Created At</TableCell>
                  <TableCell>Updated At</TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {comState.items && comState.items
                  .map((item) => {
                    return (
                      <TableRow tabIndex={-1} key={item.id}>
                        <TableCell>
                          <Avatar alt={item.name} src={item.photoUrl} sx={{ width: '3rem', height: '3rem' }}></Avatar>
                        </TableCell>
                        <TableCell>{item.name}</TableCell>
                        <TableCell>{item.email}</TableCell>
                        <TableCell>{item.roles.map(role => (<Chip key={role.name} label={role.name} className='mr-2' />))}</TableCell>
                        <TableCell
                          className='whitespace-nowrap'>{format(new Date(item.createdAt), 'yyyy-MM-dd')}</TableCell>
                        <TableCell
                          className='whitespace-nowrap'>{format(new Date(item.updatedAt), 'yyyy-MM-dd')}</TableCell>
                        <TableCell>
                          <Menu as='div' className='relative inline-block text-left'>
                            <div>
                              <Menu.Button className='btn-action'>
                                <MoreVertIcon className='text-gray-500' />
                              </Menu.Button>
                            </div>
                            <Menu.Items className='s-menu'>
                              <Menu.Item>
                                <button className='s-menu__btn' onClick={() => showEditBox(item)}>Edit</button>
                              </Menu.Item>
                              <Menu.Item>
                                <button className='s-menu__btn' onClick={() => showDeleteBox(item)}>Delete</button>
                              </Menu.Item>
                            </Menu.Items>
                          </Menu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          </TableContainer>
        </Paper>
      )}

      <Dialog
        open={comState.openDeleteBox}
        onClose={handleDeleteBoxClose}
        aria-labelledby='alert-dialog-title'
        aria-describedby='alert-dialog-description'
      >
        <DialogContent>
          <DialogContentText id='alert-dialog-description'>
            Are you sure you want to delete the post?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteBoxClose}>Cancel</Button>
          <Button onClick={handleDeleteBoxSubmit} autoFocus>
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      <Drawer anchor='right' open={openDetailBox} onClose={() => setOpenDetailBox(false)}>
        <RoleDetail data={comState.currentItem} callback={callbackSaveDetail}/>
      </Drawer>

      <Backdrop
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={comState.openBackdrop}
      >
        <CircularProgress color='inherit' />
      </Backdrop>
    </div>
  );
}
