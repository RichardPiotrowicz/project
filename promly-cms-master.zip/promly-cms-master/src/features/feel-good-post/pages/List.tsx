export default function FeelGoodPostList() {
  return (
    <div className="feel-good-post-post-page">
      Feel good post list
    </div>
  );
}
