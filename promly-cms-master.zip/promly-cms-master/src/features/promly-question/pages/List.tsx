export default function PromlyQuestionList() {
  return (
    <div className="promly-question-page">
      Promly question list
    </div>
  );
}
