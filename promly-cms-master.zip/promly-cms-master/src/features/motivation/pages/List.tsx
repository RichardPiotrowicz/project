export default function MotivationList() {
  return (
    <div className="motivation-page">
      Motivation list
    </div>
  );
}
