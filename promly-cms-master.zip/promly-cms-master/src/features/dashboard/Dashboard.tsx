import './Dashboard.scss';
import { AreaChart, BarList, Card, DonutChart, Flex, Grid, Metric, Text, Title } from '@tremor/react';

export default function Dashboard() {

  const shop = [
    { name: '/home', value: 453 },
    { name: '/imprint', value: 351 },
    { name: '/shop', value: 271 },
    { name: '/pricing', value: 191 }
  ];

  const app = [
    { name: '/shop', value: 789 },
    { name: '/product-features', value: 676 },
    { name: '/about', value: 564 },
    { name: '/login', value: 234 },
    { name: '/downloads', value: 191 }
  ];

  const data = [
    {
      category: 'Online Shop',
      stat: '12,543',
      data: shop
    },
    {
      category: 'Mobile App',
      stat: '2,543',
      data: app
    }
  ];

  const chartData = [
    {
      Month: 'Jan 21',
      Sales: 2890,
      Profit: 2400
    },
    {
      Month: 'Feb 21',
      Sales: 1890,
      Profit: 1398
    },
    {
      Month: 'Jan 22',
      Sales: 3890,
      Profit: 2980
    }
  ];
  const cities = [
    {
      name: "New York",
      sales: 9800,
    },
    {
      name: "London",
      sales: 4567,
    },
    {
      name: "Hong Kong",
      sales: 3908,
    },
    {
      name: "San Francisco",
      sales: 2400,
    },
    {
      name: "Singapore",
      sales: 1908,
    },
    {
      name: "Zurich",
      sales: 1398,
    },
  ];

  const valueFormatter = (number: number) => `$ ${Intl.NumberFormat("us").format(number).toString()}`;

  return (
    <div className="dashboard-page">
      <Grid numItemsSm={2} numItemsLg={3} className="gap-6">
        {data.map((item) => (
          <Card key={item.category}>
            <Title>{item.category}</Title>
            <Flex
              justifyContent="start"
              alignItems="baseline"
              className="space-x-2"
            >
              <Metric>{item.stat}</Metric>
              <Text>Total views</Text>
            </Flex>
            <Flex className="mt-6">
              <Text>Pages</Text>
              <Text className="text-right">Views</Text>
            </Flex>
            <BarList
              data={item.data}
              valueFormatter={(number: number) =>
                Intl.NumberFormat('us').format(number).toString()
              }
              className="mt-2"
            />
          </Card>
        ))}
        <Card className="max-w-lg">
          <Title>Sales</Title>
          <DonutChart
            className="mt-6"
            data={cities}
            category="sales"
            index="name"
            valueFormatter={valueFormatter}
            colors={["slate", "violet", "indigo", "rose", "cyan", "amber"]}
          />
        </Card>
      </Grid>
      <Card className="mt-8">
        <Title>Performance</Title>
        <Text>Comparison between Sales and Profit</Text>
        <AreaChart
          className="mt-4 h-80"
          data={chartData}
          categories={['Sales', 'Profit']}
          index="Month"
          colors={['indigo', 'fuchsia']}
          valueFormatter={(number: number) =>
            `$ ${Intl.NumberFormat('us').format(number).toString()}`
          }
        />
      </Card>
      <div className='fill-slate-500 fill-violet-500 fill-indigo-500 fill-rose-500 fill-cyan-500 fill-amber-500 text-indigo-500 text-fuchsia-500 stroke-indigo stroke-fuchsia'></div>
    </div>
  );
}
