export enum RoleEnum {
  SuperAdmin = 'super_admin',
  Administrator = 'administrator',
  Moderator = 'moderator',
}
