import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL;

export class AccountService {
  static async get(params: any) {
    params['allOnboarding'] = true;
    const res = await axios.get(`${API_URL}/accounts`, { params });
    return res.data;
  }
}
