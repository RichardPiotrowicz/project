import Paper from '@mui/material/Paper';
import { useState, MouseEvent, ChangeEvent, useEffect } from 'react';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import Box from '@mui/material/Box';
import LoadingButton from '@mui/lab/LoadingButton';
import { AdminAccountService } from '../../roles/services/AdminAccountService.ts';
import { APIResponseUtility } from '../../../utils/APIResponse.tsx';
import Message from '../../../common/message/Message.tsx';
import { useSelector } from 'react-redux';
import { selectLoggedUser } from '../../../store/auth-slice.tsx';
import TextField from '@mui/material/TextField';

export default function AccountPassword() {
  const loggedUser = useSelector(selectLoggedUser);
  const [ password, setPassword ] = useState(null);
  const [ confirmPassword, setConfirmPassword ] = useState(null);
  const [ formState, setFormState ] = useState({
    showPassword: false,
    showConfirmPassword: false,
    error: null,
    saving: false,
  });
  const [ responseMessage, setResponseMessage ] = useState({
    error: null,
    success: null,
  });
  const handleClickShowPassword = () => setFormState({ ...formState, showPassword: !formState.showPassword });
  const handleClickShowConfirmPassword = () => setFormState({
    ...formState,
    showConfirmPassword: !formState.showConfirmPassword,
  });
  const handleMouseDownPassword = (event: MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
  };

  const checkPassword = () => {
    let error = null;
    if (password && password.length < 6) {
      error = 'Password must have at least 6 characters';
    }
    if (confirmPassword && password !== confirmPassword) {
      error = 'Password doest not match';
    }
    setFormState({...formState, error});
  }
  useEffect(checkPassword, [password, confirmPassword]);
  const changePassword = (event: ChangeEvent<HTMLInputElement>) => {
    setPassword(event.target.value);
  }
  const changeConfirmPassword = (event: ChangeEvent<HTMLInputElement>) => {
    setConfirmPassword(event.target.value);
  }
  const callbackToast = () => {
    setResponseMessage({ error: null, success: null });
  }

  const submit = async () => {
    setFormState({...formState, saving: true});
    try {
      await AdminAccountService.update({email: loggedUser.email, password});
      setResponseMessage({...responseMessage, success: ['Updated successfully']})
    } catch (e) {
      setResponseMessage({...responseMessage, error: APIResponseUtility.parseErrors(e)});
    } finally {
      setFormState({...formState, saving: false});
    }
  };
  return (
    <div className='account-page'>
      <div className='text-sm font-bold uppercase mb-3'>Change password</div>

      <Paper sx={{ width: '100%', overflow: 'hidden' }} className='p-4'>
        <Box sx={{ width: '500px' }}>
          <form onSubmit={submit}>
            <TextField
              margin='normal' fullWidth variant='outlined' size='small'
              disabled
              id="email-disabled"
              label="Email"
              defaultValue={loggedUser.email}
            />

            <FormControl margin='normal' fullWidth variant='outlined' size='small'>
              <InputLabel htmlFor='outlined-adornment-password'>Password</InputLabel>
              <OutlinedInput
                id='outlined-adornment-password'
                type={formState.showPassword ? 'text' : 'password'}
                endAdornment={
                  <InputAdornment position='end'>
                    <IconButton
                      aria-label='toggle password visibility'
                      onClick={handleClickShowPassword}
                      onMouseDown={handleMouseDownPassword}
                      edge='end'
                    >
                      {formState.showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                }
                label='Password'
                autoComplete='off'
                required
                onChange={changePassword}
              />
            </FormControl>
            <FormControl margin='normal' fullWidth variant='outlined' size='small'>
              <InputLabel htmlFor='outlined-adornment-confirm-password'>Confirm Password</InputLabel>
              <OutlinedInput
                id='outlined-adornment-confirm-password'
                type={formState.showConfirmPassword ? 'text' : 'password'}
                endAdornment={
                  <InputAdornment position='end'>
                    <IconButton
                      aria-label='toggle password visibility'
                      onClick={handleClickShowConfirmPassword}
                      onMouseDown={handleMouseDownPassword}
                      edge='end'
                    >
                      {formState.showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                }
                label='Confirm Password'
                autoComplete='off'
                required
                onChange={changeConfirmPassword}
              />
            </FormControl>

            {formState.error && <div className='my-3 text-red-400 text-sm'>{formState.error}</div>}

            <Message error={responseMessage.error} success={responseMessage.success} callback={callbackToast}/>

            <LoadingButton
              variant='contained'
              disabled={!!formState.error || !password || !confirmPassword}
              loading={formState.saving}
              className='mt-4 bg-blue-600'
              onClick={submit}
            >Save</LoadingButton>
          </form>
        </Box>
      </Paper>
    </div>
  );
}
