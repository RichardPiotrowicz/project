import { useEffect, useState } from 'react';
import Loading from '../../../common/loading/Loading.tsx';
import { AccountService } from '../services/AccountService.ts';
import format from 'date-fns/format';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputAdornment from '@mui/material/InputAdornment';
import SearchIcon from '@mui/icons-material/Search';
import IconButton from '@mui/material/IconButton';
import Paper from '@mui/material/Paper';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
let searchTimeoutId = null;

export default function AccountList() {
  const [ loading, setLoading ] = useState(true);
  const [ accounts, setAccounts ] = useState([]);
  const [ keyword, setKeyword ] = useState(null);
  const [ page, setPage ] = useState(1);
  const take = 10;
  const loadData = () => {
    if (!loading) {
      setLoading(true);
    }
    if (searchTimeoutId) {
      clearTimeout(searchTimeoutId);
      searchTimeoutId = null;
    }

    searchTimeoutId = setTimeout(() => {
      const params: any = {
        take, skip: take * (page - 1)
      };
      if (keyword) {
        params.keyword = keyword;
      }
      AccountService.get(params)
        .then((res) => {
          setAccounts(res.data.items);
        })
        .finally(() => {
          setLoading(false);
        });
    }, 400);
  }
  useEffect(() => {
    if (!keyword || (keyword && 2 <= keyword.length)) {
      loadData();
    }
  }, [page, keyword]);
  const nextPage = async () => {
    setPage(page + 1);
  };
  const prevPage = async () => {
    setPage(page > 1 ? (page - 1) : 1);
  }
  const changeKeyword = (value: string) => {
    setPage(1);
    setKeyword(value);
  }
  return (
    <div className="account-page">
      <div className='text-sm font-bold uppercase mb-3'>Accounts</div>

      <div className='flex flex-row justify-between pb-3 border-b-1 border-gray-200'>
        <Stack spacing={2} direction='row'>
          <OutlinedInput
            size='small'
            style={{backgroundColor: '#ffffff'}}
            id="input-search"
            placeholder='Search'
            startAdornment={
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            }
            onChange={(e) => changeKeyword(e.target.value)}
          />
        </Stack>
      </div>

      {loading && (
        <div className='w-full relative h-40'><Loading /></div>
      )}

      {!loading && (
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
          <TableContainer sx={{ maxHeight: 'calc(100vh - 300px)' }} className='border-b-1 border-gray-300'>
            <Table stickyHeader aria-label='sticky table' size="small">
              <TableHead>
                <TableRow>
                  <TableCell></TableCell>
                  <TableCell>Name</TableCell>
                  <TableCell>Username</TableCell>
                  <TableCell>Email</TableCell>
                  <TableCell align='center'>Finished Onboarding</TableCell>
                  <TableCell>Created At</TableCell>
                  <TableCell>Updated At</TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {accounts
                  .map((item) => {
                    return (
                      <TableRow tabIndex={-1} key={item.id}>
                        <TableCell>
                          <Avatar alt={item.name} src={item.photoUrl} sx={{ width: '3rem', height: '3rem' }}></Avatar>
                        </TableCell>
                        <TableCell>{item.name}</TableCell>
                        <TableCell>{item.username}</TableCell>
                        <TableCell>{item.email}</TableCell>
                        <TableCell align='center'>
                          {!item.showOnboarding ? (<CheckBoxIcon color='primary'/>) : null}
                        </TableCell>
                        <TableCell
                          className='whitespace-nowrap'>{format(new Date(item.createdAt), 'yyyy-MM-dd')}</TableCell>
                        <TableCell
                          className='whitespace-nowrap'>{format(new Date(item.updatedAt), 'yyyy-MM-dd')}</TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          </TableContainer>

          <div className='mt-2 py-2 flex items-center justify-end  pr-4'>
            <span className='mr-8'>Rows per page: {take}</span>
            <span className='mr-8'>Page: {page}</span>
            <IconButton color="primary" aria-label="Previous" onClick={prevPage} disabled={page === 1}>
              <ChevronLeftIcon />
            </IconButton>
            <IconButton color="primary" aria-label="Next" onClick={nextPage} disabled={!accounts.length || accounts.length < take}>
              <ChevronRightIcon />
            </IconButton>
          </div>
        </Paper>
      )}
    </div>
  );
}
