import { RoleEnum } from './AccountConstants.ts';

export class AccountUtility {
  static isSuperAdmin(user: any) {
    return user && Array.isArray(user.roles) && user.roles.includes(RoleEnum.SuperAdmin);
  }
}
