import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Divider from '@mui/material/Divider';
import Container from '@mui/material/Container';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import Chip from '@mui/material/Chip';
import { ChangeEvent, useEffect, useState } from 'react';
import OutlinedInput from '@mui/material/OutlinedInput';
import { Theme, useTheme } from '@mui/material/styles';
import { INTERESTS } from '../../../common/interest/constants.ts';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { InterestService } from '../../../common/interest/InterestService.ts';
import { PromlyPostService } from '../services/PromlyPostService.ts';
import Uploader from '../../../common/uploader/Uploader.tsx';

interface PostDetailProps {
  data: any;
  callback: () => void;
}

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

export default function PostDetail({ data, callback }: PostDetailProps) {
  const [ post, setPost ] = useState(data ? data : {
    type: 'article',
    status: 'draft',
    title: '',
    description: '',
    url: '',
    interests: [],
    imageId: '',
    imageUrl: '',
  });
  const theme = useTheme();
  const existingInterests = data && data.interests ? data.interests.map((item) => item.name) : [];
  const [ selectedInterests, setSelectedInterests ] = useState<string[]>(existingInterests);
  const allInterests = INTERESTS.map((item) => item.name);
  const [ interestMap, setInterestMap ] = useState<Map<string, string>>(null);

  const loadInterests = () => {
    InterestService.get()
      .then(res => {
        console.log(res.data.data);
        const map = new Map();
        res.data.data.forEach((item) => {
          map.set(item.name, item.id);
        })
        setInterestMap(map);
      });
  }

  useEffect(() => {
    loadInterests();
  }, []);

  const handleChangeInterests = (event: SelectChangeEvent<typeof selectedInterests>) => {
    const { target: { value } } = event;
    setSelectedInterests(typeof value === 'string' ? value.split(',') : value);
  };

  const getStyles = (name: string, selectedInterests: readonly string[], theme: Theme) => {
    return {
      fontWeight:
        selectedInterests.indexOf(name) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    };
  };

  const submit = async () => {
    const postData = {
      title: post.title,
      description: post.description,
      status: post.status,
      type: post.type,
      url: post.url,
      imageId: post.imageId,
      interestIds: selectedInterests.map((item) => interestMap.get(item)),
    };
    await PromlyPostService.updateOrCreate(postData, post.id);
    callback();
  }
  return (
    <Box
      sx={{ width: 550 }}
      role='presentation'
    >
      <Container>
        <Box
          component='form'
          noValidate
          autoComplete='off'
          className='pt-6'
        >
          <Typography variant='h5' component='h5' className='mb-2'>
            {post.id ? 'Update post' : 'Create a new post'}
          </Typography>
          <Divider />

          <FormControl margin='normal' fullWidth>
            <InputLabel id='post-type-label'>Type</InputLabel>
            <Select
              labelId='post-type-label'
              id='post-type-select'
              label='Type'
              value={post.type}
              onChange={(event: SelectChangeEvent) => setPost({ ...post, type: event.target.value })}
            >
              <MenuItem value='article'>Article</MenuItem>
              <MenuItem value='video'>Video</MenuItem>
              <MenuItem value='podcast'>Podcast</MenuItem>
              <MenuItem value='event'>Event</MenuItem>
            </Select>
          </FormControl>
          <FormControl margin='normal' fullWidth>
            <InputLabel id='post-status-label'>Status</InputLabel>
            <Select
              labelId='post-status-label'
              id='post-status-select'
              label='Status'
              value={post.status}
              onChange={(event: SelectChangeEvent) => setPost({ ...post, status: event.target.value })}
            >
              <MenuItem value='published'>Published</MenuItem>
              <MenuItem value='draft'>Draft</MenuItem>
              <MenuItem value='archived'>Archived</MenuItem>
            </Select>
          </FormControl>
          <TextField
            label='Title'
            fullWidth
            margin='normal'
            value={post.title}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setPost({ ...post, title: event.target.value })}
          />
          <TextField
            label='Description'
            multiline
            rows={4}
            value={post.description}
            fullWidth margin='normal'
            onChange={(event: ChangeEvent<HTMLInputElement>) => setPost({ ...post, description: event.target.value })}
          />
          <TextField
            label='URL'
            fullWidth
            margin='normal'
            value={post.url}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setPost({ ...post, url: event.target.value })}
          />

          <FormControl margin='normal' fullWidth>
            <InputLabel id='post-interests-label'>Interests</InputLabel>
            <Select
              labelId='post-interests-label'
              id='post-interests-select'
              multiple
              value={selectedInterests}
              onChange={handleChangeInterests}
              input={<OutlinedInput id='select-interests' label='Interest' />}
              renderValue={(selected) => (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {selected.map((value) => (
                    <Chip key={value} label={value} />
                  ))}
                </Box>
              )}
              MenuProps={MenuProps}
            >
              {allInterests.map((name) => (
                <MenuItem
                  key={name}
                  value={name}
                  style={getStyles(name, selectedInterests, theme)}
                >
                  {name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <div className='w-full my-4'>
            <Uploader
              imageUrl={post.imageUrl}
              callbackUploaded={(imageId, imageUrl) => setPost({...post, imageId, imageUrl})}
              callbackRemove={() => setPost({...post, imageId: null, imageUrl: null})}
            />
          </div>
        </Box>


        <div className='flex justify-end mt-4'>
          <Button variant='contained' className='bg-blue-600' disableElevation onClick={submit}>
            {post.id ? 'Update' : 'Create'}
          </Button>
        </div>

      </Container>
    </Box>
  );
}
