import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL;

export class PromlyPostService {
  static async get(params: any) {
    const res = await axios.get(`${API_URL}/promly-posts`, { params });
    return res.data;
  }

  static async deletePosts(ids: string[]) {
    const res = await axios.delete(`${API_URL}/promly-posts`, { data: { ids } });
    return res.data;
  }

  static async updateStatus(ids: string[], status: string) {
    const res = await axios.patch(`${API_URL}/promly-posts/status`, { ids, status });
    return res.data;
  }

  static async update(id: string, data: any) {
    const res = await axios.patch(`${API_URL}/promly-posts/${id}`, data);
    return res.data;
  }

  static async create(data: any) {
    const res = await axios.post(`${API_URL}/promly-posts`, data);
    return res.data;
  }

  static async updateOrCreate(data: any, id?: string) {
    if (id) {
      const res = await axios.patch(`${API_URL}/promly-posts/${id}`, data);
      return res.data;
    }
    const res = await axios.post(`${API_URL}/promly-posts`, data);
    return res.data;
  }
}
