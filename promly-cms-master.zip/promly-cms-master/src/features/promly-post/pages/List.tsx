import { ChangeEvent, useEffect, useRef, useState } from 'react';
import Loading from '../../../common/loading/Loading.tsx';
import { PromlyPostService } from '../services/PromlyPostService.ts';
import { Menu } from '@headlessui/react';
import format from 'date-fns/format';
import InterestList from '../../../common/interest/InterestTags.tsx';
// import FilterAltOutlinedIcon from '@mui/icons-material/FilterAltOutlined';
import Avatar from '@mui/material/Avatar';
import BrokenImageOutlinedIcon from '@mui/icons-material/BrokenImageOutlined';
import Checkbox from '@mui/material/Checkbox';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';
import IconButton from '@mui/material/IconButton';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogActions from '@mui/material/DialogActions';
import Dialog from '@mui/material/Dialog';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import RadioGroup from '@mui/material/RadioGroup';
import Radio from '@mui/material/Radio';
import FormControlLabel from '@mui/material/FormControlLabel';
import AddIcon from '@mui/icons-material/Add';
import Drawer from '@mui/material/Drawer';
import PostDetail from '../post-detail/PostDetail.tsx';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import SearchIcon from '@mui/icons-material/Search';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputAdornment from '@mui/material/InputAdornment';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import MoreVertIcon from '@mui/icons-material/MoreVert';

export default function PromlyPostList() {
  const [ loading, setLoading ] = useState(true);
  const [ items, setItems ] = useState([]);
  const [ keyword, setKeyword ] = useState(null);
  // const [ showFilter, setShowFilter ] = useState(null);
  const [ selectedIds, setSelectedIds ] = useState([]);
  const [ selectedAll, setSelectedAll ] = useState(false);
  const [ page, setPage ] = useState(1);
  const take = 10;
  const [ newStatus, setNewStatus ] = useState('published');
  const [ openDeleteBox, setOpenDeleteBox ] = useState(false);
  const [ openUpdateBox, setOpenUpdateBox ] = useState(false);
  const [ openBackdrop, setOpenBackdrop ] = useState(false);
  const [ openDetailBox, setOpenDetailBox ] = useState(false);
  const [ currentItem, setCurrentItem ] = useState(null);


  const loadData = () => {
    setLoading(true);
    const params: any = {
      take, skip: take * (page - 1),
    };
    if (keyword) {
      params.keyword = keyword;
    }
    PromlyPostService.get(params)
      .then((res) => {
        const newItems = res.data.items.map((item) => ({ ...item, selected: false }));
        setItems(newItems);
      })
      .finally(() => {
        setLoading(false);
      });
  };
  useEffect(() => {
    loadData();
  }, [ page, keyword ]);
  const nextPage = async () => {
    setPage(page + 1);
  };
  const prevPage = async () => {
    setPage(page > 1 ? (page - 1) : 1);
  };
  const changeKeyword = (value: string) => {
    setPage(1);
    setKeyword(value);
  };
  // const showFilters = () => {
  //   setShowFilter(!showFilter);
  // }
  const handleToggleItem = (id: string) => {
    const newItems = items.map((item) => {
      if (item.id === id) {
        return { ...item, selected: !item.selected };
      } else {
        return { ...item };
      }
    });
    setItems(newItems);
    const selectedIds = newItems.filter((item) => item.selected).map((item) => item.id);
    setSelectedIds(selectedIds);
    if (0 < selectedIds.length && selectedIds.length === items.length) {
      setSelectedAll(true);
    } else {
      setSelectedAll(false);
    }
  };
  const handleToggleAll = () => {
    const select = !selectedAll;
    const newItems = items.map((item) => {
      return { ...item, selected: select };
    });
    setItems(newItems);
    setSelectedAll(select);
    const selectedIds = newItems.filter((item) => item.selected).map((item) => item.id);
    setSelectedIds(selectedIds);
  };
  const handleDeleteBoxClose = () => {
    setOpenBackdrop(false);
    setOpenDeleteBox(false);
  };
  const handleDeleteBoxSubmit = async () => {
    setOpenBackdrop(true);
    try {
      await PromlyPostService.deletePosts(selectedIds);
      setOpenDeleteBox(false);
      await loadData();
    } catch (e) {
      //
    } finally {
      setOpenBackdrop(false);
    }
  };
  const handleUpdateBoxClose = () => {
    setOpenBackdrop(false);
    setOpenUpdateBox(false);
  };
  const handleUpdateBoxSubmit = async () => {
    setOpenBackdrop(true);
    try {
      await PromlyPostService.updateStatus(selectedIds, newStatus);
      setOpenUpdateBox(false);
      await loadData();
    } catch (e) {
      //
    } finally {
      setOpenBackdrop(false);
    }
  };
  const radioGroupRef = useRef<HTMLElement>(null);

  const handleStatusChange = (event: ChangeEvent<HTMLInputElement>) => {
    setNewStatus((event.target as HTMLInputElement).value);
  };
  const showEditBox = (item: any) => {
    setCurrentItem(item);
    setOpenDetailBox(true);
  };

  const newPost = () => {
    setCurrentItem(null);
    setOpenDetailBox(true);
  };

  const callbackPostDetail = () => {
    setOpenDetailBox(false);
    loadData();
  }

  return (
    <div className='promly-post-page'>
      <div className='text-sm font-bold uppercase mb-3'>Promly posts</div>

      <div className='flex flex-row justify-between pb-3 border-b-1 border-gray-200'>
        <Stack spacing={2} direction='row'>
          <OutlinedInput
            size='small'
            style={{backgroundColor: '#ffffff'}}
            id="input-search"
            placeholder='Search'
            startAdornment={
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            }
            onChange={(e) => changeKeyword(e.target.value)}
          />
          {/*<IconButton onClick={showFilters}>*/}
          {/*  <FilterAltOutlinedIcon />*/}
          {/*</IconButton>*/}
        </Stack>

        <Stack spacing={2} direction='row'>
          <IconButton color='primary' disabled={!selectedIds.length} onClick={() => {
            setOpenDeleteBox(true);
          }}>
            <DeleteIcon />
          </IconButton>
          <Button variant='outlined' size='small' disabled={!selectedIds.length} onClick={() => {
            setOpenUpdateBox(true);
          }}>Change Status</Button>
          <Button variant='contained' size='small' className='bg-blue-600' disableElevation startIcon={<AddIcon />}
                  onClick={newPost}>
            Add a new post
          </Button>
        </Stack>
      </div>

      {/*{showFilter && (*/}
      {/*  <div className='flex py-4'>Filter conditions here</div>*/}
      {/*)}*/}

      {loading && (
        <div className='w-full relative h-40'><Loading /></div>
      )}

      {!loading && (
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
          <TableContainer sx={{ maxHeight: 'calc(100vh - 300px)' }} className='border-b-1 border-gray-300'>
            <Table stickyHeader aria-label='sticky table' size="small" className='pb-20'>
              <TableHead>
                <TableRow>
                  <TableCell className='td-head-sticky'>
                    <Checkbox
                      checked={selectedAll}
                      onChange={handleToggleAll}
                      inputProps={{ 'aria-label': 'controlled' }}
                    />
                  </TableCell>
                  <TableCell></TableCell>
                  <TableCell>Title</TableCell>
                  <TableCell>Description</TableCell>
                  <TableCell align='center'>Status</TableCell>
                  <TableCell align='center'>Type</TableCell>
                  <TableCell>URL</TableCell>
                  <TableCell>Interests</TableCell>
                  <TableCell>Created At</TableCell>
                  <TableCell>Updated At</TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {items
                  .map((item) => {
                    return (
                      <TableRow tabIndex={-1} key={item.id}>
                        <TableCell className='td-sticky'>
                          <Checkbox
                            checked={item.selected}
                            onChange={() => handleToggleItem(item.id)}
                            inputProps={{ 'aria-label': 'controlled' }}
                          />
                        </TableCell>
                        <TableCell>
                          {item.imageUrl ? (
                            <Avatar alt={item.title} src={item.imageUrl} sx={{ width: '3rem', height: '3rem' }}>
                              <BrokenImageOutlinedIcon />
                            </Avatar>
                          ) : <div className='w-12 h-12 rounded-full mx-auto border border-gray-200'></div>}
                        </TableCell>
                        <TableCell>
                          <div className='w-[200px] whitespace-break-spaces'>{item.title}</div>
                        </TableCell>
                        <TableCell>
                          <div className='short-des max-w-[250px]'>{item.description}</div>
                        </TableCell>
                        <TableCell align='center'>{item.status}</TableCell>
                        <TableCell align='center'>{item.type}</TableCell>
                        <TableCell>
                          <div className='short-des max-w-[150px]'>
                            {item.url ? (<a href={item.url} target='_blank'>{item.url}</a>) : null}
                          </div>
                        </TableCell>
                        <TableCell style={{ minWidth: 200, maxWidth: 250 }}>
                          <InterestList items={item.interests} />
                        </TableCell>
                        <TableCell
                          className='whitespace-nowrap'>{format(new Date(item.createdAt), 'yyyy-MM-dd')}</TableCell>
                        <TableCell
                          className='whitespace-nowrap'>{format(new Date(item.updatedAt), 'yyyy-MM-dd')}</TableCell>
                        <TableCell>
                          <Menu as='div' className='relative inline-block text-left'>
                            <div>
                              <Menu.Button className='btn-action'>
                                <MoreVertIcon className='text-gray-500' />
                              </Menu.Button>
                            </div>
                            <Menu.Items className='s-menu'>
                              <Menu.Item>
                                <button className='s-menu__btn' onClick={() => showEditBox(item)}>Edit</button>
                              </Menu.Item>
                              <Menu.Item>
                                <button className='s-menu__btn'>Delete</button>
                              </Menu.Item>
                            </Menu.Items>
                          </Menu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          </TableContainer>

          <div className='mt-2 py-2 flex items-center justify-end  pr-4'>
            <span className='mr-8'>Rows per page: {take}</span>
            <span className='mr-8'>Page: {page}</span>
            <IconButton color="primary" aria-label="Previous" onClick={prevPage} disabled={page === 1}>
              <ChevronLeftIcon />
            </IconButton>
            <IconButton color="primary" aria-label="Next" onClick={nextPage}>
              <ChevronRightIcon />
            </IconButton>
          </div>
        </Paper>
      )}

      <Dialog
        open={openDeleteBox}
        onClose={handleDeleteBoxClose}
        aria-labelledby='alert-dialog-title'
        aria-describedby='alert-dialog-description'
      >
        <DialogContent>
          <DialogContentText id='alert-dialog-description'>
            Are you sure you want to delete the items?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteBoxClose}>Cancel</Button>
          <Button onClick={handleDeleteBoxSubmit} autoFocus>
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        maxWidth='xs'
        open={openUpdateBox}
        onClose={handleUpdateBoxClose}
        aria-labelledby='alert-dialog-title'
        aria-describedby='alert-dialog-description'
      >
        <DialogContent dividers className='min-w-[220px]'>
          <DialogContentText id='alert-dialog-description'>
            Choose status
          </DialogContentText>
          <RadioGroup
            ref={radioGroupRef}
            aria-label='ringtone'
            name='ringtone'
            value={newStatus}
            onChange={handleStatusChange}
          >
            <FormControlLabel
              value='published'
              key='published'
              control={<Radio />}
              label='Published'
            />
            <FormControlLabel
              value='draft'
              key='draft'
              control={<Radio />}
              label='Draft'
            />
            <FormControlLabel
              value='archived'
              key='archived'
              control={<Radio />}
              label='Archived'
            />
          </RadioGroup>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleUpdateBoxClose}>Cancel</Button>
          <Button onClick={handleUpdateBoxSubmit} autoFocus>
            Submit
          </Button>
        </DialogActions>
      </Dialog>

      <Drawer anchor='right' open={openDetailBox} onClose={() => setOpenDetailBox(false)}>
        <PostDetail data={currentItem} callback={callbackPostDetail}/>
      </Drawer>

      <Backdrop
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={openBackdrop}
      >
        <CircularProgress color='inherit' />
      </Backdrop>
    </div>
  );
}
