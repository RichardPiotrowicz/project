import { useEffect, useState } from 'react';
import Loading from '../../../common/loading/Loading.tsx';
import { ResourceService } from '../services/ResourceService.ts';
import { Menu } from '@headlessui/react';
import format from 'date-fns/format';
import Button from '@mui/material/Button';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogActions from '@mui/material/DialogActions';
import Dialog from '@mui/material/Dialog';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import TocOutlinedIcon from '@mui/icons-material/TocOutlined';
import Stack from '@mui/material/Stack';
import AddIcon from '@mui/icons-material/Add';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import DragIndicatorIcon from '@mui/icons-material/DragIndicator';
import LoadingButton from '@mui/lab/LoadingButton';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import { CardMedia } from '@mui/material';
import Drawer from '@mui/material/Drawer';
import ResourceDetail from '../components/ResourceDetail.tsx';

const reorder = (list, startIndex, endIndex) => {
  const result: any[] = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);
  result.forEach((item, index) => {
    item.order = index;
  })

  return result;
};

const getItemStyle = (isDragging, draggableStyle) => ({
  ...draggableStyle,
  ...(isDragging && {
    background: "rgb(235,235,235)"
  })
});

export default function ReportList() {
  const [ comState, setComState ] = useState({
    loading: false,
    items: [],
    openDeleteBox: false,
    openBackdrop: false,
    currentItem: null,
    savingOrder: false,
    changedOrder: false,
  });
  const [ openDetailBox, setOpenDetailBox ] = useState(false);


  const saveOrder = async () => {
    if (!comState.changedOrder || comState.savingOrder) {
      return;
    }
    setComState({...comState, savingOrder: true});
    await ResourceService.updateOrder({ items: comState.items.map((item) => ({ id: item.id, order: item.order })) });
    setComState({...comState, savingOrder: false, changedOrder: false});
  }
  const loadData = async () => {
    setComState({...comState, loading: true});
    try {
      const res = await ResourceService.get({all: true});
      setComState({...comState, loading: false, items: res.data.items});
    } catch (e) {
      console.log('error while loading data');
    }
  };
  useEffect(() => {
    loadData();
  }, []);
  const handleDeleteBoxClose = () => {
    setComState({...comState, openBackdrop: false, openDeleteBox: false});
  };
  const handleDeleteBoxSubmit = async () => {
    if (!comState.currentItem) {
      return;
    }
    setComState({...comState, openBackdrop: true});
    try {
      await ResourceService.delete(comState.currentItem.id);
    } catch (e) {
      //
    } finally {
      setComState({...comState, openBackdrop: false, openDeleteBox: false, items: comState.items.filter(item => item.id !== comState.currentItem.id)});
    }
  };

  const showDeleteBox = (item: any) => {
    setComState({...comState, openBackdrop: true, openDeleteBox: true, currentItem: item});
  };

  const onDragEnd = async (result) => {
    if (!result.destination) {
      return;
    }
    const newItems: any[] = reorder(
      comState.items,
      result.source.index,
      result.destination.index
    );
    setComState({...comState, items: newItems, changedOrder: true});
  }

  const callbackSaveDetail = () => {
    setOpenDetailBox(false);
    loadData();
  }
  const showEditBox = (item: any) => {
    setComState({...comState, currentItem: item});
    setOpenDetailBox(true);
  };
  const newResource = () => {
    setComState({...comState, currentItem: null});
    setOpenDetailBox(true);
  };


  return (
    <div className='post-report-page'>
      <div className='text-sm font-bold uppercase mb-3'>Resources</div>

      <div className='flex flex-row justify-end pb-3 border-b-1 border-gray-200'>
        <Stack spacing={2} direction='row'>
          <LoadingButton
            variant='outlined'
            disabled={!comState.changedOrder}
            onClick={saveOrder}
            loading={comState.savingOrder}
            startIcon={<TocOutlinedIcon/>}
          >Save</LoadingButton>
          <Button variant='contained' className='bg-blue-600' disableElevation startIcon={<AddIcon />} onClick={newResource}>
            Add resource
          </Button>
        </Stack>
      </div>

      {comState.loading && (
        <div className='w-full relative h-40'><Loading /></div>
      )}

      {!comState.loading && (
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
          <TableContainer sx={{ maxHeight: 'calc(100vh - 200px)' }} className='border-b-1 border-gray-300'>
            <Table stickyHeader aria-label='sticky table' size="small" className='pb-20'>
              <TableHead>
                <TableRow>
                  <TableCell className='py-4'></TableCell>
                  <TableCell className='py-4'></TableCell>
                  <TableCell className='py-4'>Name</TableCell>
                  <TableCell className='py-4'>Description</TableCell>
                  <TableCell className='py-4'>Website</TableCell>
                  <TableCell className='py-4' align='center'>Status</TableCell>
                  <TableCell className='py-4' align='center'>Talk to someone</TableCell>
                  <TableCell className='py-4'>Created At</TableCell>
                  <TableCell className='py-4'>Updated At</TableCell>
                  <TableCell className='py-4'></TableCell>
                </TableRow>
              </TableHead>
              <DragDropContext onDragEnd={onDragEnd}>
                <Droppable droppableId="droppable">
                  {(provided) => (
                    <TableBody ref={provided.innerRef} {...provided.droppableProps}>
                      {comState.items
                        .map((item, index) => {
                          return (
                            <Draggable key={item.id} draggableId={item.id} index={index}>
                              {(provided, snapshot) => (
                                <TableRow
                                  tabIndex={-1}
                                  ref={provided.innerRef}
                                  key={item.id}
                                  {...provided.draggableProps}
                                  style={getItemStyle(
                                    snapshot.isDragging,
                                    provided.draggableProps.style
                                  )}
                                >
                                  <TableCell
                                    {...provided.dragHandleProps}
                                  >
                                    <DragIndicatorIcon />
                                  </TableCell>
                                  <TableCell>
                                    <CardMedia
                                      component='div'
                                      sx={{ width: 80, height: 80 }}
                                      image={item.imageUrl}
                                    />
                                  </TableCell>
                                  <TableCell className='max-w-[250px] min-w-[250px]'>
                                    {item.name}
                                  </TableCell>
                                  <TableCell>
                                    <div className='max-w-[250px] short-des'>{item.description}</div>
                                  </TableCell>
                                  <TableCell>
                                    <div className='max-w-[250px] short-des'>{item.websiteUrl}</div>
                                  </TableCell>
                                  <TableCell align='center'>
                                    {item.status}
                                  </TableCell>
                                  <TableCell align='center'>
                                    {item.displayInTalkToSomeone ? (<CheckBoxIcon color='primary'/>) : (<CheckBoxOutlineBlankIcon color='disabled'/>)}
                                  </TableCell>
                                  <TableCell
                                    className='whitespace-nowrap'>{format(new Date(item.createdAt), 'yyyy-MM-dd')}</TableCell>
                                  <TableCell
                                    className='whitespace-nowrap'>{format(new Date(item.updatedAt), 'yyyy-MM-dd')}</TableCell>
                                  <TableCell>
                                    <Menu as='div' className='relative inline-block text-left'>
                                      <div>
                                        <Menu.Button className='btn-action'>
                                          <MoreVertIcon className='text-gray-500' />
                                        </Menu.Button>
                                      </div>
                                      <Menu.Items className='s-menu'>
                                        <Menu.Item>
                                          <button className='s-menu__btn' onClick={() => showEditBox(item)}>Edit</button>
                                        </Menu.Item>
                                        <Menu.Item>
                                          <button className='s-menu__btn' onClick={() => showDeleteBox(item)}>Delete</button>
                                        </Menu.Item>
                                      </Menu.Items>
                                    </Menu>
                                  </TableCell>
                                </TableRow>
                              )}
                            </Draggable>
                          );
                        })}
                      {provided.placeholder}
                    </TableBody>
                  )}
                </Droppable>
              </DragDropContext>

            </Table>
          </TableContainer>
        </Paper>
      )}

      <Dialog
        open={comState.openDeleteBox}
        onClose={handleDeleteBoxClose}
        aria-labelledby='alert-dialog-title'
        aria-describedby='alert-dialog-description'
      >
        <DialogContent>
          <DialogContentText id='alert-dialog-description'>
            Are you sure you want to delete the post?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteBoxClose}>Cancel</Button>
          <Button onClick={handleDeleteBoxSubmit} autoFocus>
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      <Drawer anchor='right' open={openDetailBox} onClose={() => setOpenDetailBox(false)}>
        <ResourceDetail data={comState.currentItem} callback={callbackSaveDetail}/>
      </Drawer>

      <Backdrop
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={comState.openBackdrop}
      >
        <CircularProgress color='inherit' />
      </Backdrop>
    </div>
  );
}
