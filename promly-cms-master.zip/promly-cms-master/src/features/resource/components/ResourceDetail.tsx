import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Divider from '@mui/material/Divider';
import Container from '@mui/material/Container';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { ChangeEvent, useState } from 'react';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { ResourceService } from '../services/ResourceService.ts';
import Uploader from '../../../common/uploader/Uploader.tsx';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';

interface ResourceDetailProps {
  data: any;
  callback: () => void;
}

export default function ResourceDetail({ data, callback }: ResourceDetailProps) {
  const [ resource, setResource ] = useState(data ? data : {
    status: 'draft',
    name: '',
    description: '',
    websiteUrl: '',
    displayInTalkToSomeone: false,
    chatLink: '',
    chatSubtext: '',
    callNumber: '',
    callSubtext: '',
    textNumber: '',
    textSubtext: '',
    imageId: '',
    imageUrl: '',
  });

  const submit = async () => {
    const resourceData = {
      status: resource.status,
      name: resource.name,
      description: resource.description,
      websiteUrl: resource.websiteUrl,
      displayInTalkToSomeone: resource.displayInTalkToSomeone,
      chatLink: resource.chatLink,
      chatSubtext: resource.chatSubtext,
      callNumber: resource.callNumber,
      callSubtext: resource.callSubtext,
      textNumber: resource.textNumber,
      textSubtext: resource.textSubtext,
      imageId: resource.imageId,
    };
    await ResourceService.updateOrCreate(resourceData, resource.id);
    callback();
  }
  return (
    <Box
      sx={{ width: 550 }}
      role='presentation'
    >
      <Container>
        <Box
          component='form'
          noValidate
          autoComplete='off'
          className='py-6'
        >
          <Typography variant='h5' component='h5' className='mb-2'>
            {resource.id ? 'Update resource' : 'Create a new resource'}
          </Typography>
          <Divider />

          <FormControl margin='normal' fullWidth>
            <InputLabel id='resource-status-label'>Status</InputLabel>
            <Select
              labelId='resource-status-label'
              id='resource-status-select'
              label='Status'
              value={resource.status}
              onChange={(event: SelectChangeEvent) => setResource({ ...resource, status: event.target.value })}
            >
              <MenuItem value='published'>Published</MenuItem>
              <MenuItem value='draft'>Draft</MenuItem>
              <MenuItem value='archived'>Archived</MenuItem>
            </Select>
          </FormControl>
          <TextField
            label='Name'
            fullWidth
            margin='normal'
            value={resource.name}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setResource({ ...resource, name: event.target.value })}
          />
          <TextField
            label='Description'
            multiline
            rows={4}
            value={resource.description ?? ''}
            fullWidth margin='normal'
            onChange={(event: ChangeEvent<HTMLInputElement>) => setResource({ ...resource, description: event.target.value })}
          />
          <TextField
            label='websiteUrl'
            fullWidth
            margin='normal'
            value={resource.websiteUrl ?? ''}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setResource({ ...resource, websiteUrl: event.target.value })}
          />

          <FormControlLabel
            className='ml-0 my-4'
            value="start"
            control={<Checkbox
              checked={resource.displayInTalkToSomeone}
              onChange={(event: ChangeEvent<HTMLInputElement>) => setResource({ ...resource, displayInTalkToSomeone: event.target.checked })}
              inputProps={{ 'aria-label': 'controlled' }}
            />}
            label="Display in talk to someone"
            labelPlacement="start"
          />

          <TextField
            label='chatLink'
            fullWidth
            margin='normal'
            value={resource.chatLink ?? ''}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setResource({ ...resource, chatLink: event.target.value })}
          />

          <TextField
            label='chatSubtext'
            fullWidth
            margin='normal'
            value={resource.chatSubtext ?? ''}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setResource({ ...resource, chatSubtext: event.target.value })}
          />

          <TextField
            label='callNumber'
            fullWidth
            margin='normal'
            value={resource.callNumber ?? ''}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setResource({ ...resource, callNumber: event.target.value })}
          />

          <TextField
            label='callSubtext'
            fullWidth
            margin='normal'
            value={resource.callSubtext ?? ''}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setResource({ ...resource, callSubtext: event.target.value })}
          />

          <TextField
            label='textNumber'
            fullWidth
            margin='normal'
            value={resource.textNumber ?? ''}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setResource({ ...resource, textNumber: event.target.value })}
          />

          <TextField
            label='textSubtext'
            fullWidth
            margin='normal'
            value={resource.textSubtext ?? ''}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setResource({ ...resource, textSubtext: event.target.value })}
          />

          <div className='w-full my-4'>
            <Uploader
              imageUrl={resource.imageUrl}
              callbackUploaded={(imageId, imageUrl) => setResource({...resource, imageId, imageUrl})}
              callbackRemove={() => setResource({...resource, imageId: null, imageUrl: null})}
            />
          </div>


          <div className='flex justify-end mt-4'>
            <Button variant='contained' className='bg-blue-600' disableElevation onClick={submit}>
              {resource.id ? 'Update' : 'Create'}
            </Button>
          </div>
        </Box>

      </Container>
    </Box>
  );
}
