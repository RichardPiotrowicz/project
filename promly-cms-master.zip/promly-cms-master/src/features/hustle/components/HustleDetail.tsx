import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Divider from '@mui/material/Divider';
import Container from '@mui/material/Container';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { ChangeEvent, useState } from 'react';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { HustleService } from '../services/HustleService.ts';
import Uploader from '../../../common/uploader/Uploader.tsx';
import { MuiChipsInput } from 'mui-chips-input';

const HustleCategories = [
  {name: 'Serve', value: 'serve'},
  {name: 'Earn', value: 'earn'},
  {name: 'Learn', value: 'learn'},
  {name: 'Create', value: 'create'},
];

interface HustleDetailProps {
  data: any;
  callback: () => void;
}

export default function HustleDetail({ data, callback }: HustleDetailProps) {
  const [ hustle, setHustle ] = useState(data ? data : {
    status: 'draft',
    title: '',
    category: '',
    url: '',
    tags: [],
    imageId: null,
    imageUrl: '',
  });

  const submit = async () => {
    const hustleData = {
      status: hustle.status,
      title: hustle.title,
      category: hustle.category,
      url: hustle.url,
      tags: hustle.tags,
      imageId: hustle.imageId,
    };
    await HustleService.updateOrCreate(hustleData, hustle.id);
    callback();
  }

  const handleChangeTags = (newTags) => {
    console.log(newTags)
    setHustle({...hustle, tags: newTags})
  }
  return (
    <Box
      sx={{ width: 550 }}
      role='presentation'
    >
      <Container>
        <Box
          component='form'
          noValidate
          autoComplete='off'
          className='py-6'
        >
          <Typography variant='h5' component='h5' className='mb-2'>
            {hustle.id ? 'Update hustle' : 'Create a new hustle'}
          </Typography>
          <Divider />

          <FormControl margin='normal' fullWidth>
            <InputLabel id='hustle-status-label'>Status</InputLabel>
            <Select
              labelId='hustle-status-label'
              id='hustle-status-select'
              label='Status'
              value={hustle.status}
              onChange={(event: SelectChangeEvent) => setHustle({ ...hustle, status: event.target.value })}
            >
              <MenuItem value='published'>Published</MenuItem>
              <MenuItem value='draft'>Draft</MenuItem>
              <MenuItem value='archived'>Archived</MenuItem>
            </Select>
          </FormControl>
          <TextField
            label='Title'
            fullWidth
            margin='normal'
            value={hustle.title}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setHustle({ ...hustle, title: event.target.value })}
          />
          <FormControl margin='normal' fullWidth>
            <InputLabel id='hustle-category-label'>Category</InputLabel>
            <Select
              labelId='hustle-category-label'
              id='hustle-category-select'
              label='Category'
              value={hustle.category}
              onChange={(event: SelectChangeEvent) => setHustle({ ...hustle, category: event.target.value })}
            >
              {HustleCategories.map(item => (
                <MenuItem key={item.value} value={item.value}>{item.name}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            label='Url'
            fullWidth
            margin='normal'
            value={hustle.url ?? ''}
            onChange={(event: ChangeEvent<HTMLInputElement>) => setHustle({ ...hustle, url: event.target.value })}
          />

          <MuiChipsInput
            label='Tags'
            margin='normal'
            fullWidth
            value={hustle.tags}
            onChange={handleChangeTags}
          />

          <div className='w-full my-4'>
            <Uploader
              imageUrl={hustle.imageUrl}
              callbackUploaded={(imageId, imageUrl) => setHustle({...hustle, imageId, imageUrl})}
              callbackRemove={() => setHustle({...hustle, imageId: null, imageUrl: null})}
            />
          </div>


          <div className='flex justify-end mt-4'>
            <Button variant='contained' className='bg-blue-600' disableElevation onClick={submit}>
              {hustle.id ? 'Update' : 'Create'}
            </Button>
          </div>
        </Box>

      </Container>
    </Box>
  );
}
