import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL;

export class HustleService {
  static async get(params: any) {
    const res = await axios.get(`${API_URL}/hustles`, { params });
    return res.data;
  }

  static async update(id: string, data: any) {
    const res = await axios.patch(`${API_URL}/hustles/${id}`, data);
    return res.data;
  }

  static async delete(id: string) {
    const res = await axios.delete(`${API_URL}/hustles/${id}`);
    return res.data;
  }

  static async updateOrder(data: {items: any[]}) {
    const res = await axios.patch(`${API_URL}/hustles/order`, data);
    return res.data;
  }

  static async getOrder() {
    const res = await axios.get(`${API_URL}/hustles/order`);
    return res.data;
  }

  static async updateOrCreate(data: any, id?: string) {
    if (id) {
      const res = await axios.patch(`${API_URL}/hustles/${id}`, data);
      return res.data;
    }
    const res = await axios.post(`${API_URL}/hustles`, data);
    return res.data;
  }
}
