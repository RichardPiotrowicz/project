import { createSlice } from '@reduxjs/toolkit';
import { AppState } from './store';

export interface MessageState {
  error: string[];
  success: string[];
}

const initialState: MessageState = {
  error: [],
  success: [],
};

export const messageSlice = createSlice({
  name: 'message',
  initialState,
  reducers: {
    setErrorMessages(state, action) {
      state.error = action.payload;
    },
    setSuccessMessages(state, action) {
      state.success = action.payload;
    },
  },
});

export const { setErrorMessages, setSuccessMessages } = messageSlice.actions;

export const selectErrorMessages = (state: AppState) => state.message.error;
export const selectSuccessMessages = (state: AppState) => state.message.success;

export default messageSlice.reducer;
