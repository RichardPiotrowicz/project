import { createSlice } from '@reduxjs/toolkit';
import jwt_decode from 'jwt-decode';
import { AppState } from './store';

// Type for our state
export interface AuthState {
  token?: string;
  authStatus?: boolean;
  loggedUser?: any;
}

const token = localStorage.getItem('token');

// Initial state
const initialState: AuthState = {
  token: token,
  authStatus: !!token,
  loggedUser: token ? jwt_decode(token) : null,
};

// Actual Slice
console.log('initialState', initialState);
export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setAuthToken(state, action) {
      state.token = action.payload;
      state.authStatus = !!action.payload;
      state.loggedUser = action.payload ? jwt_decode(action.payload) : null;
      if (action.payload) {
        localStorage.setItem('token', action.payload);
      } else {
        localStorage.removeItem('token');
      }
    },
    setLoggedUser(state, action) {
      state.loggedUser = action.payload;
    },
  },
});

export const { setAuthToken, setLoggedUser } = authSlice.actions;

export const selectAuthStatus = (state: AppState) => state.auth.authStatus;
export const selectLoggedUser = (state: AppState) => state.auth.loggedUser;

export default authSlice.reducer;
