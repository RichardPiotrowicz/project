import { NavLink } from 'react-router-dom';
import './Nav.scss';
import DashboardOutlinedIcon from '@mui/icons-material/DashboardOutlined';
import PeopleAltOutlinedIcon from '@mui/icons-material/PeopleAltOutlined';
import InterestsOutlinedIcon from '@mui/icons-material/InterestsOutlined';
import AutoGraphOutlinedIcon from '@mui/icons-material/AutoGraphOutlined';
import ApartmentOutlinedIcon from '@mui/icons-material/ApartmentOutlined';
import FlashOffOutlinedIcon from '@mui/icons-material/FlashOffOutlined';
import TipsAndUpdatesOutlinedIcon from '@mui/icons-material/TipsAndUpdatesOutlined';
import NewspaperOutlinedIcon from '@mui/icons-material/NewspaperOutlined';
import QuizOutlinedIcon from '@mui/icons-material/QuizOutlined';
import SelfImprovementOutlinedIcon from '@mui/icons-material/SelfImprovementOutlined';
import WbSunnyOutlinedIcon from '@mui/icons-material/WbSunnyOutlined';
import ReportOutlinedIcon from '@mui/icons-material/ReportOutlined';
import SupervisorAccountIcon from '@mui/icons-material/SupervisorAccount';
import { useSelector } from 'react-redux';
import { selectLoggedUser } from '../../store/auth-slice.tsx';
import { AccountUtility } from '../../features/account/AccountUtility.ts';
import Link from '@mui/material/Link';

export default function AppNav() {
  const loggedUser = useSelector(selectLoggedUser, { stabilityCheck: 'always' });
  const isSuperAdmin = AccountUtility.isSuperAdmin(loggedUser);
  return (
    <nav className='app-nav'>
      <ul className='nav-list'>
        <li className='nav-list__item'>
          <Link component={NavLink} to="/"><DashboardOutlinedIcon /> Dashboard</Link>
        </li>
        <li className='nav-list__item'>
          <Link component={NavLink} to='/accounts'><PeopleAltOutlinedIcon /> Accounts</Link>
        </li>
        <li className='nav-list__item'>
          <Link component={NavLink} to='/interests'><InterestsOutlinedIcon /> Interests</Link>
        </li>
        <li className='nav-list__item'>
          <Link component={NavLink} to='/motivations'><AutoGraphOutlinedIcon /> Motivations</Link>
        </li>
        <li className='nav-list__item'>
          <Link component={NavLink} to='/resources'><ApartmentOutlinedIcon /> Resources</Link>
        </li>
        <li className='nav-list__item'>
          <Link component={NavLink} to='/hustles'><FlashOffOutlinedIcon /> Hustles</Link>
        </li>
        <li className='nav-list__item'>
          <Link component={NavLink} to='/ideas'><TipsAndUpdatesOutlinedIcon /> Ideas</Link>
        </li>
        <li className='nav-list__item'>
          <Link component={NavLink} to='/promly-posts'><NewspaperOutlinedIcon />Promly posts</Link>
        </li>
        <li className='nav-list__item'>
          <Link component={NavLink} to='/promly-questions'><QuizOutlinedIcon />Promly Questions</Link>
        </li>
        <li className='nav-list__item'>
          <Link component={NavLink} to='/relaxation-posts'><SelfImprovementOutlinedIcon /> Relaxation posts</Link>
        </li>
        <li className='nav-list__item'>
          <Link component={NavLink} to='/feel-good-posts'><WbSunnyOutlinedIcon /> Feel good posts</Link>
        </li>
        <li className='nav-list__item'>
          <Link component={NavLink} to='/post-reports'><ReportOutlinedIcon /> Reports</Link>
        </li>

        {isSuperAdmin ? (
          <li className='nav-list__item'>
            <Link component={NavLink} to='/roles'><SupervisorAccountIcon /> Manage roles</Link>
          </li>
        ) : null}
      </ul>
    </nav>
  );
}
