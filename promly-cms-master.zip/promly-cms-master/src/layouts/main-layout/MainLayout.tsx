import { Outlet } from 'react-router-dom';
import AppHeader from '../header/Header.tsx';
import AppNav from '../nav/Nav.tsx';
import './MainLayout.scss';

export default function MainLayout() {
  return (
    <>
      <AppHeader></AppHeader>
      <main className='main-layout flex flex-row'>
        <AppNav></AppNav>
        <div className='main-content'><Outlet /></div>
      </main>
    </>
  );
}
