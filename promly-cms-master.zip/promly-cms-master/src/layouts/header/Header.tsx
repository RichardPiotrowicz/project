import './Header.scss';
import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import IconButton from '@mui/material/IconButton';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import Link from '@mui/material/Link';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';

export default function AppHeader() {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <header className="app-header">
      <div className="header-left">
        <a className="header-logo flex logo" href="/">
          <img src='images/logo.svg' alt='Promly Admin'/>
        </a>
      </div>
      <div className="flex flex-row">
        <ul className='header-links'>
          <li className='header-links__item'>
            <IconButton
              onClick={handleClick}
              size="small"
              sx={{ ml: 2 }}
              aria-controls={open ? 'account-menu' : undefined}
              aria-haspopup="true"
              aria-expanded={open ? 'true' : undefined}
            >
              <AccountCircleIcon fontSize='large' style={{color: '#ffffff'}}/>
            </IconButton>
            <Menu
              id="demo-positioned-menu"
              aria-labelledby="demo-positioned-button"
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
            >
              <MenuItem children={<Link component={NavLink} to='/account/password' underline="none" color="inherit"><ManageAccountsIcon className='mr-2'/> Profile</Link>} onClick={handleClose}></MenuItem>
              <MenuItem children={<Link href='/auth/logout' underline="none" color="inherit"><LogoutOutlinedIcon className='mr-2'/> Logout</Link>} onClick={handleClose}></MenuItem>
            </Menu>
          </li>
        </ul>
      </div>
    </header>
  );
}
