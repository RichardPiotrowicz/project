import ReactDOM from 'react-dom/client';
import { StyledEngineProvider,createTheme, ThemeProvider } from '@mui/material/styles';
// import CssBaseline from '@mui/material/CssBaseline';
import axios from 'axios';
import App from './App.tsx';
import './index.css';

axios.interceptors.request.use(function(config) {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

const rootElement = document.getElementById("root");

const theme = createTheme({
  components: {
    MuiPopover: {
      defaultProps: {
        container: rootElement,
      },
    },
    MuiPopper: {
      defaultProps: {
        container: rootElement,
      },
    },
    MuiDialog: {
      defaultProps: {
        container: rootElement,
      },
    },
    MuiModal: {
      defaultProps: {
        container: rootElement,
      },
    },
  },
});

ReactDOM.createRoot(rootElement!).render(
  <StyledEngineProvider injectFirst>
    <ThemeProvider theme={theme}>
      {/*<CssBaseline />*/}
      <App />
    </ThemeProvider>
  </StyledEngineProvider>,
);
