import { useSelector } from 'react-redux';
import { Navigate, useLocation } from 'react-router-dom';
import { selectAuthStatus } from './store/auth-slice.tsx';

const ProtectedRoute = (data: { children: any }) => {
  const authStatus = useSelector(selectAuthStatus);
  const location = useLocation();

  if (!authStatus) {
    return <Navigate to='/auth/login' state={{ from: location }} replace />;
  }
  return data.children;

};

export default ProtectedRoute;
