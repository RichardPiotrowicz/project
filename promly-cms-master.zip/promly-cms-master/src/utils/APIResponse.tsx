import { AxiosError } from 'axios';

export class APIResponseUtility {
  static parseErrors(e: AxiosError | any) {
    let messages;
    const data: any = e && e.response && e.response.data ? e.response.data : null;
    switch (true) {
      case data && data.messages && Array.isArray(data.messages):
        messages = data.messages;
        break;
      case data && data.messages:
        messages = [data.messages];
        break;
      case data && data.message:
        messages = [data.message];
        break;
      default:
        messages = [e.message];
    }
    return messages;
  }
}
