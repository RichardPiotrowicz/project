export class CommonUtility {
  static getRequestHeaders() {
    return {Authorization : `Bearer ${localStorage.getItem('token')}`};
  }
}
