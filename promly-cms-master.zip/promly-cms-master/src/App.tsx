import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.scss';
import AccountList from './features/account/pages/List.tsx';
import HustleList from './features/hustle/pages/List.tsx';
import PromlyPostList from './features/promly-post/pages/List.tsx';
import Dashboard from './features/dashboard/Dashboard.tsx';
import MainLayout from './layouts/main-layout/MainLayout.tsx';
import AuthLayout from './layouts/AuthLayout';
import Login from './features/auth/pages/Login.tsx';
import ReduxProvider from './store/redux-provider.tsx';
import IdeaList from './features/idea/pages/List.tsx';
import ProtectedRoute from './ProtectedRoute.tsx';
import Logout from './features/auth/pages/Logout.tsx';
import ForgotPassword from './features/auth/pages/ForgotPassword.tsx';
import LoginWithCode from './features/auth/pages/LoginWithCode.tsx';
import InterestList from './features/interest/pages/List.tsx';
import MotivationList from './features/motivation/pages/List.tsx';
import ResourceList from './features/resource/pages/List.tsx';
import PromlyQuestionList from './features/promly-question/pages/List.tsx';
import RelaxationPostList from './features/relaxation-post/pages/List.tsx';
import FeelGoodPostList from './features/feel-good-post/pages/List.tsx';
import PostReportList from './features/post-report/pages/List.tsx';
import RoleList from './features/roles/pages/List.tsx';
import AccountPassword from './features/account/pages/Password.tsx';

function App() {
  return (
    <ReduxProvider>
      <div className='app-wrapper'>
        <BrowserRouter>
          <Routes>
            <Route element={<AuthLayout />}>
              <Route path='/auth/login' element={<Login />} />
              <Route path='/auth/login-code' element={<LoginWithCode />} />
              <Route path='/auth/logout' element={<Logout />} />
              <Route path='/auth/forgot-password' element={<ForgotPassword />} />
            </Route>

            <Route path='/' element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
              <Route path='/' element={<Dashboard />} />
              <Route path='/accounts' element={<AccountList />} />
              <Route path='/interests' element={<InterestList />} />
              <Route path='/motivations' element={<MotivationList />} />
              <Route path='/resources' element={<ResourceList />} />
              <Route path='/hustles' element={<HustleList />} />
              <Route path='/ideas' element={<IdeaList />} />
              <Route path='/promly-posts' element={<PromlyPostList />} />
              <Route path='/promly-questions' element={<PromlyQuestionList />} />
              <Route path='/relaxation-posts' element={<RelaxationPostList />} />
              <Route path='/feel-good-posts' element={<FeelGoodPostList />} />
              <Route path='/post-reports' element={<PostReportList />} />
              <Route path='/roles' element={<RoleList />} />
              <Route path='/account/password' element={<AccountPassword />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </div>
    </ReduxProvider>
  );
}

export default App;
